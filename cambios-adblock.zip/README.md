# Acid Mod Loader

La app abre **https://acidorg.com/#mods** dentro de una ventana pywebview y le inyecta JavaScript que:

1. Agrega un botón flotante para elegir tu carpeta de Brawlhalla (se recuerda en `config.json`).
2. Convierte los botones "Download ↓" de la grilla de mods en "Install ⚡".
3. Al hacer click, Python descarga el archivo y lo instala (swf sueltos, `bones*`, zips de mapart, `.bmod` con merge de sprites/sonidos vía FFDec).

También funciona en GameBanana (`gamebanana.com/mods/games/5704`), con botón de ir y volver, y tiene un panel **📦 Installed mods** para desinstalar (con respaldo de los archivos originales en `%LOCALAPPDATA%\AcidModLoader\backups\`).

`api.install_mod` solo acepta URLs de `acidorg.com` y `gamebanana.com`.

---

## Estructura del repo

```
launcher.py          Entrypoint del .exe. Cambia casi nunca.
build_exe.py         Empaqueta el .exe con PyInstaller (onefile + JRE).
build_payload.py     Genera payload.zip + manifest.json para un release.
publicar_update.bat  Atajo: build_payload + crear release en GitHub.
subir_a_github.bat   Commit + push del código fuente.
requirements.txt
icon.ico
vendor/              JRE 17 + ffdec_lib.jar y sus dependencias (pesado).
payload/             TODO el código liviano. Esto es lo que se actualiza.
  app_main.py          (antes main.py) crea la ventana e inyecta los JS
  api.py  installer.py  mod_registry.py  bmod_reader.py  swf_sprite_merge.py
  config.py  appdirs.py  updater.py  adblock.py
  adblock_rules.json  *_inject.js  update_inject.js  adblock_inject.js
  version.json
```

## Cómo funcionan las actualizaciones

| Qué | Dónde vive | Cuándo cambia |
|---|---|---|
| `vendor/` (JRE + FFDec) | Se copia **una vez** a `%LOCALAPPDATA%\AcidModLoader\vendor` | Casi nunca |
| Código liviano (`payload/`) | Copia de respaldo dentro del `.exe`; copias nuevas en `%LOCALAPPDATA%\AcidModLoader\app` | Cada release |
| `launcher.py` + librerías de Python | Dentro del `.exe` | Solo si cambias dependencias (hay que redistribuir el `.exe`) |

1. Al abrir, `launcher.py` elige el payload con la versión más alta entre el de AppData y el empaquetado.
2. El botón **⟳ Updates** (abajo a la derecha) consulta `releases/latest/download/manifest.json`. Si hay versión nueva muestra un puntito rojo.
3. "Update now" descarga `payload.zip`, verifica el SHA-256, lo deja en `app.pending` y reinicia la app. El launcher lo activa antes de importar nada.
4. Si el payload nuevo crashea en los primeros 20 segundos, se mueve a `app.bad` y se arranca el empaquetado.

### Publicar una actualización

```
python build_payload.py 1.1.0 "Qué cambió"
gh release create v1.1.0 release/payload.zip release/manifest.json --title v1.1.0 --notes "Qué cambió"
```

o simplemente doble clic a `publicar_update.bat`. Los dos assets deben llamarse exactamente `payload.zip` y `manifest.json`.

### Cuándo SÍ hay que redistribuir el .exe

- Agregaste una librería nueva de Python (o cambiaste la versión de pywebview/JPype).
- Cambiaste el JRE o FFDec en `vendor/` (además, borra `%LOCALAPPDATA%\AcidModLoader\vendor` o cambia el marcador `.copied`).
- Cambiaste `launcher.py`.

Si el payload nuevo necesita un `.exe` nuevo, sube `LAUNCHER_API` en `launcher.py` **y** en `build_payload.py`: el botón avisará al usuario en vez de instalar algo que no puede correr.

### Seguridad

El payload descargado se ejecuta con los permisos del usuario. El SHA-256 protege contra descargas corruptas, no contra una cuenta de GitHub comprometida (el manifest viene del mismo release). Activa 2FA en tu cuenta.

---

## Bloqueador de anuncios (GameBanana)

Activado por defecto, solo dentro de la ventana de la app y solo para `gamebanana.com`. Se apaga con la casilla **Block ads on GameBanana** del panel ⟳ Updates (muestra también cuántas peticiones bloqueó).

Tiene tres capas independientes (`payload/adblock.py`):

1. **Red:** WebView2 corta las peticiones a dominios de anuncios (`adblock_rules.json` → `domains`) antes de descargarlas. Si esta capa no se puede activar, la app sigue funcionando con las otras dos y el panel lo avisa.
2. **CSS:** oculta los contenedores de anuncios (`selectors`).
3. **Aviso anti-bloqueador:** oculta el cartel "Ads keep us online / please consider unblocking us" (`notice`).

Las reglas viajan en el payload, así que se corrigen con un release sin redistribuir el `.exe`. Cada usuario puede añadir las suyas en `%LOCALAPPDATA%\AcidModLoader\adblock_user.json`:

```json
{ "domains": ["ads.ejemplo.com"], "selectors": [".caja-publicidad"], "allow": [], "notice": [] }
```

Nota: GameBanana se financia solo con anuncios (su propio aviso lo dice), así que si usas la app a menudo considera apoyarlos de otra forma.

## Desarrollo

```
pip install -r requirements.txt
cd payload
python app_main.py
```

(o `python launcher.py` desde la raíz, que es lo mismo que hace el .exe).

## Configurar `vendor/ffdec_lib.jar`

`ffdec_lib.jar` solo no alcanza: FFDec necesita sus jars de terceros (`tomlj`, `jsyntaxpane`, `commons-io`, …). Baja una release de [FFDec](https://github.com/jindrapetrik/jpexs-decompiler/releases) y copia `ffdec_lib.jar` **y** su carpeta de dependencias dentro de `vendor/`. La app arma el classpath buscando cualquier `.jar` bajo la carpeta de `ffdec_lib.jar`.

## Empaquetar a .exe

```
python build_payload.py 1.0.0     # escribe payload/version.json
python build_exe.py
```

`build_exe.py` descarga un JRE 17 portable a `vendor/jre/` (una vez), verifica `vendor/ffdec_lib.jar`, escanea los imports de `payload/` para pasarlos a PyInstaller como `--hidden-import`, y genera `dist/AcidModLoader.exe` (onefile, con JRE y payload adentro) + `Run AcidModLoader.bat`.

Para PCs sin Visual C++ Runtime / WebView2, reparte el `.exe` junto al `.bat`: instala lo que falte en silencio. Manualmente: [VC++ Redistributable x64](https://aka.ms/vs/17/release/vc_redist.x64.exe) y [WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/).

Primer arranque: se copia el JRE + FFDec (~45 MB) a `%LOCALAPPDATA%\AcidModLoader\vendor`; es más lento solo esa vez.

## Mods instalados y desinstalación

Antes de escribir en la carpeta de Brawlhalla, `mod_registry.py` guarda el original en `backups/` y anota la instalación en `installed_mods.json`. Al desinstalar se restauran los archivos reemplazados y se borran los creados. Si dos mods tocan el mismo archivo, desinstalar el más viejo deja el archivo como lo dejó el más nuevo. Los mods instalados antes del registro no tienen respaldo: usa "Verificar integridad de los archivos del juego" en Steam.

## Cambiar de dominio

Edita `ACID_URL` / `GAMEBANANA_URL` en `payload/app_main.py` y `ALLOWED_HOSTS` / `NAV_ALLOWED_HOSTS` en `payload/api.py`, y publica un release: no hace falta redistribuir el .exe.

## Limitación conocida

Los `.bmod` de legends que son SWF crudo, sin metadata de qué archivo del juego reemplazan, no están soportados.
